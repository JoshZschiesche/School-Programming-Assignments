//Josh Zschiesche
//CSCE 121-502
//Due: October 8,2015
//randint.h


int randint();
