//Josh Zschiesche
//CSCE 121-502
//Due: October 8,2015
//hw4pr1.cpp

#include "randint.h"
#include "std_lib_facilities_4.h"
int main()
{
        int num0 = 0;
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        int num4 = 0;
        int num5 = 0;
        int num6 = 0;
        int num7 = 0;
        int num8 = 0;
        int num9 = 0;

    for (int i = 0; i <= 1000000; ++i)
    {
        int random = randint();
        int last_rand_char = random%10; 

        switch (last_rand_char)
        {
            case 0:
                {
                    ++num0;
                    break;
                }
            case 1:
                {
                    ++num1;
                    break;
                }
            case 2:
                {
                    ++num2;
                    break;
                }
            case 3:
                {
                    ++num3;
                    break;
                }
            case 4:
                {
                    ++num4;
                    break;
                }
            case 5:
                {
                    ++num5;
                    break;
                }
            case 6:
                {
                    ++num6;
                    break;
                }
            case 7:
                {
                    ++num7;
                    break;
                }
            case 8:
                {
                    ++num8;
                    break;
                }
            case 9:
                {
                    ++num9;
                    break;
                }
    }
    }
    cout << "there were " << setw(15) << num0 << " numbers that ended in 0\n";
    cout << "there were " << setw(15) << num1 << " numbers that ended in 1\n";
    cout << "there were " << setw(15) << num2 << " numbers that ended in 2\n";
    cout << "there were " << setw(15) << num3 << " numbers that ended in 3\n";
    cout << "there were " << setw(15) << num4 << " numbers that ended in 4\n";
    cout << "there were " << setw(15) << num5 << " numbers that ended in 5\n";
    cout << "there were " << setw(15) << num6 << " numbers that ended in 6\n";
    cout << "there were " << setw(15) << num7 << " numbers that ended in 7\n";
    cout << "there were " << setw(15) << num8 << " numbers that ended in 8\n";
    cout << "there were " << setw(15) << num9 << " numbers that ended in 9\n";
}
