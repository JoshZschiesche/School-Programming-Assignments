#include "Edge.hpp"

// please implement it

Edge::Edge(int s, int e, int w)
{
	start = s;
	weight = w;
	end = e;
}